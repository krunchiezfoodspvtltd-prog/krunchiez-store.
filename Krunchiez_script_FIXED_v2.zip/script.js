document.addEventListener("DOMContentLoaded", () => {
  let cart = JSON.parse(localStorage.getItem("krunchiezCart") || "[]");

  const openCartBtn = document.getElementById("openCart");
  const closeCartBtn = document.getElementById("closeCart");
  const cartPanel = document.getElementById("cartPanel");
  const overlay = document.getElementById("overlay");
  const cartItems = document.getElementById("cartItems");
  const cartTotal = document.getElementById("cartTotal");
  const cartCount = document.getElementById("cartCount");
  const checkoutBtn = document.getElementById("checkoutBtn");
  const toast = document.getElementById("toast");

  function saveCart() {
    localStorage.setItem("krunchiezCart", JSON.stringify(cart));
  }

  function total() {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }

  function updateCartCount() {
    if (cartCount) {
      cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
    }
  }

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 1800);
  }

  function renderCart() {
    if (!cartItems) return;

    if (!cart.length) {
      cartItems.innerHTML = '<p class="empty">Your cart is waiting for a crunch.</p>';
      if (cartTotal) cartTotal.textContent = "₹0";
      updateCartCount();
      return;
    }

    cartItems.innerHTML = cart.map((item, index) => `
      <div class="cart-item">
        <div class="cart-item-info">
          <strong>${item.name}</strong>
          <span>₹${item.price} × ${item.quantity}</span>
        </div>
        <div class="cart-item-actions">
          <button type="button" data-action="decrease" data-index="${index}">−</button>
          <span>${item.quantity}</span>
          <button type="button" data-action="increase" data-index="${index}">+</button>
          <button type="button" data-action="remove" data-index="${index}">Remove</button>
        </div>
      </div>
    `).join("");

    if (cartTotal) cartTotal.textContent = `₹${total()}`;
    updateCartCount();
  }

  document.querySelectorAll(".add-btn[data-name]").forEach(button => {
    button.addEventListener("click", () => {
      const name = button.dataset.name;
      const price = Number(button.dataset.price);
      const weight = button.dataset.weight || "52 g";
      const existing = cart.find(item => item.name === name);

      if (existing) existing.quantity++;
      else cart.push({ name, price, weight, quantity: 1 });

      saveCart();
      renderCart();
      showToast(`${name} added to cart ✦`);
    });
  });

  cartItems?.addEventListener("click", event => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const index = Number(button.dataset.index);
    if (!cart[index]) return;

    if (button.dataset.action === "increase") cart[index].quantity++;
    if (button.dataset.action === "decrease") {
      cart[index].quantity--;
      if (cart[index].quantity <= 0) cart.splice(index, 1);
    }
    if (button.dataset.action === "remove") cart.splice(index, 1);

    saveCart();
    renderCart();
  });

  function openCart() {
    cartPanel?.classList.add("open");
    overlay?.classList.add("show");
    renderCart();
  }

  function closeCart() {
    cartPanel?.classList.remove("open");
    overlay?.classList.remove("show");
  }

  openCartBtn?.addEventListener("click", openCart);
  closeCartBtn?.addEventListener("click", closeCart);
  overlay?.addEventListener("click", closeCart);

  checkoutBtn?.addEventListener("click", () => {
    if (!cart.length) {
      showToast("Your cart is empty!");
      return;
    }

    if (document.getElementById("checkoutModal")) return;

    const modal = document.createElement("div");
    modal.id = "checkoutModal";
    modal.innerHTML = `
      <div class="checkout-overlay"></div>
      <div class="checkout-modal">
        <button type="button" class="checkout-close">×</button>
        <div class="eyebrow">KRUNCHIEZ CHECKOUT</div>
        <h2>GRAB YOUR PACKS.</h2>
        <p>Order total: <strong>₹${total()}</strong></p>
        <form id="checkoutForm">
          <label>Name
            <input id="customerName" required placeholder="Your name">
          </label>
          <label>Phone
            <input id="customerPhone" required inputmode="numeric"
                   pattern="[0-9]{10}" maxlength="10"
                   placeholder="10-digit mobile number">
          </label>
          <label>Delivery address
            <textarea id="customerAddress" required
                      placeholder="House / street / area / city / pincode"></textarea>
          </label>
          <button class="btn btn-dark" type="submit" style="width:100%">
            PLACE ORDER →
          </button>
          <p class="checkout-help">
            This currently prepares the order by email. Online payment and courier
            integration will be connected separately.
          </p>
        </form>
      </div>
    `;

    document.body.appendChild(modal);

    const close = () => modal.remove();
    modal.querySelector(".checkout-close").addEventListener("click", close);
    modal.querySelector(".checkout-overlay").addEventListener("click", close);

    modal.querySelector("#checkoutForm").addEventListener("submit", event => {
      event.preventDefault();

      const name = modal.querySelector("#customerName").value.trim();
      const phone = modal.querySelector("#customerPhone").value.trim();
      const address = modal.querySelector("#customerAddress").value.trim();

      const order = cart.map(item =>
        `${item.name} x ${item.quantity} = ₹${item.price * item.quantity}`
      ).join("\n");

      const subject = encodeURIComponent(`Krunchiez Order - ${name}`);
      const body = encodeURIComponent(
        `New Krunchiez order\n\nCustomer: ${name}\nPhone: ${phone}\nAddress: ${address}\n\n` +
        `Order:\n${order}\n\nTotal: ₹${total()}`
      );

      window.location.href =
        `mailto:krunchiezfoodspvt.ltd@gmail.com?subject=${subject}&body=${body}`;
    });
  });

  const style = document.createElement("style");
  style.textContent = `
    .cart-item{padding:14px 0;border-bottom:1px solid rgba(0,0,0,.12)}
    .cart-item-info{display:flex;justify-content:space-between;gap:12px;margin-bottom:10px}
    .cart-item-actions{display:flex;align-items:center;gap:8px}
    .cart-item-actions button{border:1px solid #111;background:#fff;padding:5px 9px;cursor:pointer}
    .cart-item-actions button:last-child{margin-left:auto}
    .checkout-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:9998}
    .checkout-modal{position:fixed;z-index:9999;width:min(92vw,500px);max-height:90vh;overflow:auto;
      left:50%;top:50%;transform:translate(-50%,-50%);background:#fff;color:#111;padding:30px;
      box-shadow:0 20px 60px rgba(0,0,0,.35)}
    .checkout-close{position:absolute;right:15px;top:10px;border:0;background:transparent;font-size:30px;cursor:pointer}
    .checkout-modal label{display:block;margin:16px 0;font-weight:700}
    .checkout-modal input,.checkout-modal textarea{display:block;width:100%;box-sizing:border-box;
      margin-top:7px;padding:12px;border:1px solid #bbb;font:inherit}
    .checkout-modal textarea{min-height:100px;resize:vertical}
    .checkout-help{font-size:12px;opacity:.65}
  `;
  document.head.appendChild(style);

  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeCart();
  });

  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", event => {
      const target = document.querySelector(link.getAttribute("href"));
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: "smooth" });
        closeCart();
      }
    });
  });

  renderCart();
});